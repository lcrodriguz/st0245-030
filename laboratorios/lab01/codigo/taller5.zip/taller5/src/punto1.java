import java.util.Random;


public class punto1 {
    
    public static int ArrayMax( int []A, int n ){
        int max , temp =0;
        max =A[n] ;
           if(n==0){
                 max=A[0];
            }else {
                temp = ArrayMax(A , n-1);
            }
            if(temp > max){
                max=temp;
            }
             
      return max;
    } 
    
    public boolean groupSum(int start, int[] nums, int target) {
    if (start >= nums.length) return target == 0;
    return groupSum(start + 1, nums, target - nums[start])
            || groupSum(start + 1, nums, target);


}
    
    public static long fibonacci(int n) {
        if (n <= 1) return n;
        else return fibonacci(n-1) + fibonacci(n-2);
    }
    
    
    public static long tiempo (int[]a, int n){
    long startTime = System.nanoTime();
    ArrayMax(a , n);
    long estimatedTime = System.nanoTime() -
    startTime;
    
    return estimatedTime;
    }
    

    
    public static void main ( String [] args){
        int size =100;
        int max = 500000000;
        
        int[] a1 = new int[size];
        Random generator = new Random();
        for (int i =0; i<size; i++) {a1[i] = generator.nextInt(max);}
    
        System.out.println(tiempo(a1 , 99));
    }

} 
        
 